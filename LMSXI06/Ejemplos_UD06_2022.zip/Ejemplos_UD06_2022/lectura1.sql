DECLARE @addresses xml
SELECT @addresses = aliasColumna
FROM OPENROWSET (BULK 'C:\Users\wadmin\Desktop\Ejemplos_UD06\addresses.xml', SINGLE_BLOB)
AS aliasTabla (aliasColumna)


SELECT @addresses

DECLARE @hdoc int

EXEC sp_xml_preparedocument @hdoc OUTPUT, @addresses
SELECT *
FROM OPENXML (@hdoc, '/Addresses/Address' , 1)
WITH(
id INT
)

EXEC sp_xml_removedocument @hdoc