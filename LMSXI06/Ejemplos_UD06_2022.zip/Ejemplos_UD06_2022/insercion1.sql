DECLARE @addresses xml
SELECT @addresses = aliasColumna
FROM OPENROWSET (BULK 'C:\Users\wadmin\Desktop\Ejemplos_UD06\addresses.xml', SINGLE_BLOB)
AS aliasTabla (aliasColumna)
SELECT @addresses
DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @addresses

INSERT INTO AdventureWorksLT2016.SalesLT.Address (AddressLine1, City, StateProvince, CountryRegion, PostalCode)
SELECT AddressLine1, City, StateProvince, CountryRegion, PostalCode
FROM OPENXML (@hdoc, '/Addresses/Address' , 2)

WITH(
    AddressLine1  nvarchar(60) ,
	City nvarchar(30) './CountryRegion/City',
	StateProvince nvarchar(50) './CountryRegion/StateProvince',
	CountryRegion nvarchar(50) './CountryRegion/text()', 
	PostalCode nvarchar(15)	
    )
    
EXEC sp_xml_removedocument @hdoc
